//import { familysoapUI } from './soapcall.js';
//const soapcall = require('./conn');
const oracleconnection = require('./conn');
const soapcall = require('./soapcall');
const soapcallclaim = require('./Soapcallclaim');


const oracledb = require('oracledb');
var acc1;
// Get Account Name
async function getAccountNames() {
  try{
  connection = await oracledb.getConnection({
    user: 'citi_abagchi',
    password: 'U4ggPVAg9PNuJ',
    connectString: '100.112.45.151:1521/CITPDWTT'
  });
  const Account = await connection.execute(`SELECT 
  AHF."ACCOUNT_NAME"
  FROM PAYOR_DW.ALL_ACCOUNT_HISTORY_FACT AHF
       INNER JOIN PAYOR_DW.DATE_DIMENSION EFFDT ON EFFDT.DATE_KEY = AHF.VERSION_EFF_DATE_KEY
       INNER JOIN PAYOR_DW.DATE_DIMENSION EXPDT ON EXPDT.DATE_KEY = AHF.VERSION_EXP_DATE_KEY
       LEFT OUTER JOIN PAYOR_DW.TAX_ENTITY TEHF ON AHF.TAX_ENTITY_KEY = TEHF.TAX_ENTITY_KEY
       INNER JOIN PAYOR_DW.POSTAL_ADDRESS PA ON PA.POSTAL_ADDRESS_KEY = AHF.ACCOUNT_CORR_ADDRESS_KEY 
       INNER JOIN PAYOR_DW.STATE_CODE SC ON SC.STATE_CODE = PA.STATE_CODE
  WHERE 
  EFFDT.DATE_VALUE   <= SYSDATE
  AND EXPDT.DATE_VALUE > SYSDATE
  `);
  var Acc=Account.rows
  

  return {
    Acc
   }
  } catch (err) {
    console.error(err);
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error(err);
      }
    }
  }

}
async function getmemberid() {
  try{
  connection = await oracledb.getConnection({
    user: 'citi_abagchi',
    password: 'U4ggPVAg9PNuJ',
    connectString: '100.112.45.151:1521/CITPDWTT'
  });
  const Account = await connection.execute(`SELECT DISTINCT
  MHF.MEMBER_HCC_ID AS MEMBER_ID
  FROM 
  PAYOR_DW.all_member_version_hist_fact mhf, 
  PAYOR_DW.DATE_DIMENSION effDt, 
  PAYOR_DW.DATE_DIMENSION expDt
  WHERE
  effDt.DATE_KEY = mhf.VERSION_EFF_DATE_KEY and
  expDt.DATE_KEY = mhf.VERSION_EXP_DATE_KEY and
  effDt.DATE_VALUE <= SYSDATE and
  expDt.DATE_VALUE > SYSDATE and
  MHF.MEMBER_HCC_ID IS  NOT NULL
  ORDER BY mhf.member_hcc_id
  `);
  var Acc=Account.rows

  return {
    Acc
   }
  } catch (err) {
    console.error(err);
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error(err);
      }
    }
  }

}

// Post Account Name and Get Benefit Plans list 
async function getBenefitplans(data) {
  //SQL connections open 
  try{

  connection = await oracledb.getConnection({
    user: 'citi_abagchi',
    password: 'U4ggPVAg9PNuJ',
    connectString: '100.112.45.151:1521/CITPDWTT'
  });
  
  acckey= await connection.execute("SELECT account_key FROM PAYOR_DW.ALL_ACCOUNT_HISTORY_FACT where account_name='"+data+"'");
  acc1=acckey.rows[0][0];
  const benefit_pan = await connection.execute("SELECT BENEFIT_PLAN_DESC FROM payor_dw.benefit_plan bf JOIN payor_dw.account_plan_select_fact ap ON bf.benefit_plan_key=ap.benefit_plan_key WHERE ap.account_key='"+acc1+"'");  
   var bene=benefit_pan.rows

  const statename=await connection.execute("SELECT SC.STATE_NAME FROM PAYOR_DW.ALL_ACCOUNT_HISTORY_FACT AHF INNER JOIN PAYOR_DW.DATE_DIMENSION EFFDT ON EFFDT.DATE_KEY = AHF.VERSION_EFF_DATE_KEY INNER JOIN PAYOR_DW.DATE_DIMENSION EXPDT ON EXPDT.DATE_KEY = AHF.VERSION_EXP_DATE_KEY LEFT OUTER JOIN PAYOR_DW.TAX_ENTITY TEHF ON AHF.TAX_ENTITY_KEY = TEHF.TAX_ENTITY_KEY INNER JOIN PAYOR_DW.POSTAL_ADDRESS PA ON PA.POSTAL_ADDRESS_KEY = AHF.ACCOUNT_CORR_ADDRESS_KEY INNER JOIN PAYOR_DW.STATE_CODE SC ON SC.STATE_CODE = PA.STATE_CODE WHERE EFFDT.DATE_VALUE   <= SYSDATE AND EXPDT.DATE_VALUE > SYSDATE AND AHF.account_key = '"+acc1+"'");
  var state=statename.rows;

  return {
    bene,
    state
   }
  } catch (err) {
    console.error(err);
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error(err);
      }
    }
  }
  
  }
  
  async function getServiceCategory() {
    try{
    connection = await oracledb.getConnection({
      user: 'citi_abagchi',
      password: 'U4ggPVAg9PNuJ',
      connectString: '100.112.45.151:1521/CITPDWTT'
    });
    const serviceCategory = await connection.execute(`SELECT DISTINCT
    SCHF.SERVICE_CATEGORY_NAME
    --SRF.SERVICE_CODE_RANGE_START,
    --SRF.SERVICE_CODE_RANGE_END,
    --SUBSTR(REPLACE(REGEXP_SUBSTR(SCHF.DEFINITION, 'revenue code "(\d{4})"'),'revenue code ', ''),2,4) AS revenue_code,
    --REGEXP_SUBSTR(SCHF.DEFINITION, 'place of service "(\d+)"', 1, 1, 'i', 1) AS place_of_service_code,
    --REGEXP_SUBSTR(SCHF.DEFINITION, 'modifier\s*"(\w+)"', 1, 1, 'i', 1) AS modifier_code,
    --REGEXP_SUBSTR(SCHF.DEFINITION, 'type of bill "(\d+)"', 1, 1, NULL, 1) AS type_of_bill_code,
    --SUBSTR(REPLACE(regexp_substr(SCHF.DEFINITION, 'diagnosis\s(.*?)\s.*', 1, 1, NULL, 1), '"', ''), 1, LENGTH(SCHF.DEFINITION)-2)|| REGEXP_SUBSTR(SCHF.DEFINITION, 'primary diagnosis "(\w+\.\w+)"', 1, 1, 'i', 1) as Diagnosis_code,
    --SCHF.DEFINITION
    FROM PAYOR_DW.SERVICE_CATEGORY_HIST_FACT SCHF 
    --INNER JOIN PAYOR_DW.SERV_CATEGORY_X_SERV_CD_RANGE SXR 
    --ON SXR.SERVICE_CATEGORY_HIST_FACT_KEY = SCHF.SERVICE_CATEGORY_HIST_FACT_KEY
    --INNER JOIN PAYOR_DW.SERVICE_CODE_RANGE_FACT SRF 
    --ON SRF.SERVICE_CODE_RANGE_FACT_KEY = SXR.SERVICE_CODE_RANGE_FACT_KEY
    `);
    var sercat=serviceCategory.rows

    return {
      sercat
     }
    } catch (err) {
      console.error(err);
    } finally {
      if (connection) {
        try {
          await connection.close();
        } catch (err) {
          console.error(err);
        }
      }
    }
  
  }

  async function getServicecodedetails(servicecat) {


    let servicecode;
    let revenucode;
    let POC;
    let modifier;
    let typeofBill;
    let diag;
    let servicecatdata=[];

    try{

    connection = await oracledb.getConnection({
      user: 'citi_abagchi',
      password: 'U4ggPVAg9PNuJ',
      connectString: '100.112.45.151:1521/CITPDWTT'
    });

    const querystring = `SELECT DISTINCT SCHF.DEFINITION
      FROM PAYOR_DW.SERVICE_CATEGORY_HIST_FACT SCHF 
      INNER JOIN PAYOR_DW.SERV_CATEGORY_X_SERV_CD_RANGE SXR 
      ON SXR.SERVICE_CATEGORY_HIST_FACT_KEY = SCHF.SERVICE_CATEGORY_HIST_FACT_KEY
      INNER JOIN PAYOR_DW.SERVICE_CODE_RANGE_FACT SRF 
      ON SRF.SERVICE_CODE_RANGE_FACT_KEY = SXR.SERVICE_CODE_RANGE_FACT_KEY
      WHERE SCHF.SERVICE_CATEGORY_NAME='${servicecat}'`

// const querystring = `SELECT DISTINCT
// SCHF.SERVICE_CATEGORY_NAME,
// SRF.SERVICE_CODE_RANGE_START,
// SRF.SERVICE_CODE_RANGE_END,
// SUBSTR(REPLACE(REGEXP_SUBSTR(SCHF.DEFINITION, 'revenue code "(\d{4})"'),'revenue code ', ''),2,4)
// ,
// REGEXP_SUBSTR(SCHF.DEFINITION, 'place of service "(\d+)"', 1, 1, 'i', 1)
// ,
// REGEXP_SUBSTR(SCHF.DEFINITION, 'modifier\s*"(\w+)"', 1, 1, 'i', 1)
// ,
// REGEXP_SUBSTR(SCHF.DEFINITION, 'type of bill "(\d+)"', 1, 1, NULL, 1)
// ,
// SUBSTR(REPLACE(regexp_substr(SCHF.DEFINITION, 'diagnosis\s(.*?)\s.*', 1, 1, NULL, 1), '"', ''), 1, LENGTH(SCHF.DEFINITION)-2)|| REGEXP_SUBSTR(SCHF.DEFINITION, 'primary diagnosis "(\w+\.\w+)"', 1, 1, 'i', 1)
// ,
// SCHF.DEFINITION
// FROM PAYOR_DW.SERVICE_CATEGORY_HIST_FACT SCHF 
// INNER JOIN PAYOR_DW.SERV_CATEGORY_X_SERV_CD_RANGE SXR 
// ON SXR.SERVICE_CATEGORY_HIST_FACT_KEY = SCHF.SERVICE_CATEGORY_HIST_FACT_KEY
// INNER JOIN PAYOR_DW.SERVICE_CODE_RANGE_FACT SRF 
// ON SRF.SERVICE_CODE_RANGE_FACT_KEY = SXR.SERVICE_CODE_RANGE_FACT_KEY
// WHERE SCHF.SERVICE_CATEGORY_NAME='${servicecat}';`
    const serviceCategory1 = await connection.execute(querystring);
//     var sercat=serviceCategory.rows
try{
  //console.log(serviceCategory1.rows);
  data=serviceCategory1.rows[0][0];
  //const json = JSON.stringify(data);
  console.log(data);
  const substrings = data.split(" ");
  const map = new Map();
   let tempstring='';
  //pattern = r'^[^"]*"$';
  for (i=0;i<substrings.length;i++) {
   
     if (containsAlphabet(substrings[i]) && substrings[i]!='to' && substrings[i]!='and' && substrings[i].indexOf('"'))
     {
      console.log(substrings[i]);
      tempstring=tempstring.concat(substrings[i])
      if (substrings[i+1].indexOf('"')>=0){
         let qS = substrings[i+1].indexOf("\"")
         let qE = substrings[i+1].indexOf("\"",qS+1)
         let val = substrings[i+1].substring(qS+1,qE).trim()
         if (!map.has(tempstring)) {
            map.set(tempstring,val)
            tempstring='';
         }
      } 

   }
}
console.log(map);
for (const [key, value] of map) {
 // console.log(key, value);
  if(key.localeCompare('service')==0)
  {
    servicecode=value;
  }
  if(key.localeCompare('typeofbill')==0)
  {
    typeofBill=value;
  }
  if(key.localeCompare('revenuecode')==0)
  {
    revenucode=value;
  }
  if(key.localeCompare('placeofservice')==0)
  {
    POC=value;
  }
  if(key.localeCompare('modifier')==0)
  {
    modifier=value;
  }
  if(key.localeCompare('diagnosis')==0)
  {
    diag=value;
  }
  
}
console.log(servicecode);
	// servicecode=serviceCategory1.rows[0][1];
	// revenucode=serviceCategory1.rows[0][3];
	// POC=serviceCategory1.rows[0][4];
	// modifier=serviceCategory1.rows[0][5];
	// typeofBill=serviceCategory1.rows[0][6];
	// //diag=serviceCategory1.rows[0][7];
  
	}
	catch(e)
	{
    console.error(e)
    servicecode='';
    revenucode='';
    POC='';
    modifier='';
    typeofBill='';
    diag='';
	}
	servicecatdata.push({"servicecode":servicecode,"revenucode":revenucode,"POC":POC,"modifier":modifier,"typeofBill":typeofBill,"diag":diag})
	console.log(servicecatdata);
    return {
      servicecatdata
    }
    } catch (err) {
      console.error(err);
    } finally {
      if (connection) {
        try {
          await connection.close();
        } catch (err) {
          console.error(err);
        }
      }
    }
  
  }
  function containsAlphabet(string) {
    for (var i = 0; i < string.length; i++) {
      var char = string[i];
      if ((char >= 'a' && char <= 'z') || (char >= 'A' && char <= 'Z')) {
        return true;
      }
    }
    return false;
  }

  async function getdatafromSoap(SOAPData,subtype) {
   var member_id;
   var statecode='';
   var zipode='';
   var accHCCID='';
   var beneHCCID='';
   var SOAPDatanode = [];
   var firstname='';
   var lastName='';
   var address='';
   var state='';
   var gender=''
   var dob;
   var AccHCCplan;
   var beneHCCplan;
   var subname;
   var memberidref
   var sub_id;
   var subscriptionId;

//console.log(subtype);
if(subtype=="Subscriber Only")
{
    for (var i=0;i<SOAPData.length;i++)
    {
      const SSN1 = Math.floor(Math.random()*800) + 100;
      const SSN2 = Math.floor(Math.random()*80) + 10;
      const SSN3 = Math.floor(Math.random()*8000) + 1000;
      const SSN=SSN1+"-"+SSN2+"-"+SSN3;
      
      statecode=await soapcall.getdbvalue('statecode',acc1)
      console.log(SSN);
      zipode = await soapcall.getdbvalue("zipcode",acc1)
      AccHCCplan = await soapcall.getdbvalue("AccHcc",acc1)
      //beneHCCplan= await soapcall.getdbvalue("beneHcc",acc1);
      //console.log(statecode.code+" "+zipode.code+" "+AccHCCplan.code);
      statecode=statecode.code;
      subname=SOAPData[i].subscriber.replace(/[0-9]/g, '');
      //console.log(subname);
    
      //if(subname=='Subscriber'){
        subscriptionId = Math.floor(Math.random()*90000000) + 10000000;
        sub_id="A"+subscriptionId
      //}
      zipode=zipode.code;
      accHCCID=AccHCCplan.code;
      beneHCCID=SOAPData[i].Benefit_Plan;
      //console.log("benefit:"+beneHCCID);
      firstname=SOAPData[i].Firstname;
      lastName=SOAPData[i].lastname;
      address=SOAPData[i].Address;
      state=SOAPData[i].State;
      gender=SOAPData[i].Gender;
      dob =SOAPData[i].Dateofbirth;
      console.log(firstname+','+lastName+','+address+','+state+','+gender+','+dob);

        memberidref=sub_id+"00"
        member_id=await soapcall.SOAPUIConfig(firstname,lastName,address,state,gender,dob,accHCCID,beneHCCID,zipode,statecode,SSN,"Self",sub_id,memberidref);
      
      SOAPDatanode.push({
        "sub_node":SOAPData[i].subscriber,
         "Account_node":SOAPData[i].Account,
         "Benefit_Plan_node":SOAPData[i].Benefit_Plan,
         "Firstname_node":SOAPData[i].Firstname,
         "lastname_node":SOAPData[i].lastname,
         "Dateofbirth_node":SOAPData[i].Dateofbirth,
         "Gender_node":SOAPData[i].Gender,
         "Address_node":SOAPData[i].Address,
         "State_node":SOAPData[i].State,
         "MemberID_node":memberidref,
         });
      }
    }

    if(subtype=="Subscriber + Family"){
      const arrayforitrate = [];
      const SSN1 = Math.floor(Math.random()*800) + 100;
      const SSN2 = Math.floor(Math.random()*80) + 10;
      const SSN3 = Math.floor(Math.random()*8000) + 1000;
      const SSN=SSN1+"-"+SSN2+"-"+SSN3;
       
    for (var i=0;i<SOAPData.length;i++)
    {
      
      statecode=await soapcall.getdbvalue('statecode',acc1)
      //console.log(SSN);
      zipode = await soapcall.getdbvalue("zipcode",acc1)
      AccHCCplan = await soapcall.getdbvalue("AccHcc",acc1)
      //beneHCCplan= await soapcall.getdbvalue("beneHcc",acc1);
      //console.log(statecode.code+" "+zipode.code+" "+AccHCCplan.code);
      statecode=statecode.code;
      subname=SOAPData[i].subscriber.replace(/[0-9]/g, '');
      console.log(subname);
      if(subname=='Subscriber'){
        subscriptionId = Math.floor(Math.random()*90000000) + 10000000;
        sub_id="A"+subscriptionId
      }
      zipode=zipode.code;
      accHCCID=AccHCCplan.code;
      beneHCCID=SOAPData[i].Benefit_Plan;
      //console.log("benefit:"+beneHCCID);
      firstname=SOAPData[i].Firstname;
      lastName=SOAPData[i].lastname;
      address=SOAPData[i].Address;
      state=SOAPData[i].State;
      gender=SOAPData[i].Gender;
      dob=SOAPData[i].Dateofbirth;
      console.log(firstname+','+lastName+','+address+','+state+','+gender+','+dob);
      //memberidref=sub_id+"0"+i;
      if (subname=="Subscriber"){
        memberidref=sub_id+"00";
      }
      if(subname=="Spouse"){
        memberidref=sub_id+"01";
      }
      if(subname=="Child"){
        memberidref=sub_id+"02";
      }
      console.log(subname);
      console.log(memberidref);
      SOAPDatanode.push({
        "sub_node":SOAPData[i].subscriber,
         "Account_node":SOAPData[i].Account,
         "Benefit_Plan_node":SOAPData[i].Benefit_Plan,
         "Firstname_node":SOAPData[i].Firstname,
         "lastname_node":SOAPData[i].lastname,
         "Dateofbirth_node":SOAPData[i].Dateofbirth,
         "Gender_node":SOAPData[i].Gender,
         "Address_node":SOAPData[i].Address,
         "State_node":SOAPData[i].State,
         "MemberID_node":memberidref,
         });
        // console.log(SOAPDatanode);
         //let firstnameconcat="firstname"+i;
         arrayforitrate.push({"firstname":firstname,"lastName":lastName,"dob":dob,"gender":gender,"address":address,"memberid":memberidref});
         
         //console.log(arrayforitrate);
         

         //console.log(subname);
         if (subname != "Child") { continue; }
        // console.log("comin");
         //console.log(SOAPDatanode);
         member_id=await soapcall.familysoapUI(arrayforitrate,accHCCID,beneHCCID,zipode,statecode,SSN,sub_id);
      }
    }
    if(subtype=="Subscriber + children"){
      const arrayforitrate = [];
      const SSN1 = Math.floor(Math.random()*800) + 100;
      const SSN2 = Math.floor(Math.random()*80) + 10;
      const SSN3 = Math.floor(Math.random()*8000) + 1000;
      const SSN=SSN1+"-"+SSN2+"-"+SSN3;
     
    for (var i=0;i<SOAPData.length;i++)
    {
      
      statecode=await soapcall.getdbvalue('statecode',acc1)
      //console.log(SSN);
      zipode = await soapcall.getdbvalue("zipcode",acc1)
      AccHCCplan = await soapcall.getdbvalue("AccHcc",acc1)
      //beneHCCplan= await soapcall.getdbvalue("beneHcc",acc1);
      //console.log(statecode.code+" "+zipode.code+" "+AccHCCplan.code);
      statecode=statecode.code;
      subname=SOAPData[i].subscriber.replace(/[0-9]/g, '');
      //console.log(subname);
    
      if(subname=='Subscriber'){
        subscriptionId = Math.floor(Math.random()*90000000) + 10000000;
        sub_id="A"+subscriptionId
      }
      zipode=zipode.code;
      accHCCID=AccHCCplan.code;
      beneHCCID=SOAPData[i].Benefit_Plan;
      //console.log("benefit:"+beneHCCID);
      firstname=SOAPData[i].Firstname;
      lastName=SOAPData[i].lastname;
      address=SOAPData[i].Address;
      state=SOAPData[i].State;
      gender=SOAPData[i].Gender;
      dob=SOAPData[i].Dateofbirth;
      console.log(firstname+','+lastName+','+address+','+state+','+gender+','+dob);
      if (subname=="Subscriber"){memberidref=sub_id+"00";}
     // if(subname=="Spouse"){memberidref=sub_id+"01"}
      if(subname=="Child"){memberidref=sub_id+"01"}
      console.log(memberidref);
      SOAPDatanode.push({
        "sub_node":SOAPData[i].subscriber,
         "Account_node":SOAPData[i].Account,
         "Benefit_Plan_node":SOAPData[i].Benefit_Plan,
         "Firstname_node":SOAPData[i].Firstname,
         "lastname_node":SOAPData[i].lastname,
         "Dateofbirth_node":SOAPData[i].Dateofbirth,
         "Gender_node":SOAPData[i].Gender,
         "Address_node":SOAPData[i].Address,
         "State_node":SOAPData[i].State,
         "MemberID_node":memberidref,
         });
         console.log(SOAPDatanode);
         //let firstnameconcat="firstname"+i;
         arrayforitrate.push({"firstname":firstname,"lastName":lastName,"dob":dob,"gender":gender,"address":address,"memberid":memberidref});
         
         console.log(arrayforitrate);
         

         console.log(subname);
         if (subname != "Child") { continue; }
         console.log("comin");
         console.log(SOAPDatanode);
         member_id=await soapcall.childsoapUI(arrayforitrate,accHCCID,beneHCCID,zipode,statecode,SSN,sub_id);
      }
    }
    if(subtype=="Subscriber + Spouse"){
      const arrayforitrate = [];
      const SSN1 = Math.floor(Math.random()*800) + 100;
      const SSN2 = Math.floor(Math.random()*80) + 10;
      const SSN3 = Math.floor(Math.random()*8000) + 1000;
      const SSN=SSN1+"-"+SSN2+"-"+SSN3;
      
    for (var i=0;i<SOAPData.length;i++)
    {
      statecode=await soapcall.getdbvalue('statecode',acc1)
      //console.log(SSN);
      zipode = await soapcall.getdbvalue("zipcode",acc1)
      AccHCCplan = await soapcall.getdbvalue("AccHcc",acc1)
      //beneHCCplan= await soapcall.getdbvalue("beneHcc",acc1);
      //console.log(statecode.code+" "+zipode.code+" "+AccHCCplan.code);
      statecode=statecode.code;
      subname=SOAPData[i].subscriber.replace(/[0-9]/g, '');
      //console.log(subname);
    
      if(subname=='Subscriber'){
        subscriptionId = Math.floor(Math.random()*90000000) + 10000000;
        sub_id="A"+subscriptionId
      }
      zipode=zipode.code;
      accHCCID=AccHCCplan.code;
      beneHCCID=SOAPData[i].Benefit_Plan;
      //console.log("benefit:"+beneHCCID);
      firstname=SOAPData[i].Firstname;
      lastName=SOAPData[i].lastname;
      address=SOAPData[i].Address;
      state=SOAPData[i].State;
      gender=SOAPData[i].Gender;
      dob=SOAPData[i].Dateofbirth;
      console.log(firstname+','+lastName+','+address+','+state+','+gender+','+dob);
      if (subname=="Subscriber"){memberidref=sub_id+"00";}
     if(subname=="Spouse"){memberidref=sub_id+"01"}
      //if(subname=="Child"){memberidref=sub_id+"01"}
      console.log(memberidref);
      SOAPDatanode.push({
        "sub_node":SOAPData[i].subscriber,
         "Account_node":SOAPData[i].Account,
         "Benefit_Plan_node":SOAPData[i].Benefit_Plan,
         "Firstname_node":SOAPData[i].Firstname,
         "lastname_node":SOAPData[i].lastname,
         "Dateofbirth_node":SOAPData[i].Dateofbirth,
         "Gender_node":SOAPData[i].Gender,
         "Address_node":SOAPData[i].Address,
         "State_node":SOAPData[i].State,
         "MemberID_node":memberidref,
         });
         console.log(SOAPDatanode);
         //let firstnameconcat="firstname"+i;
         arrayforitrate.push({"firstname":firstname,"lastName":lastName,"dob":dob,"gender":gender,"address":address,"memberid":memberidref});
         
         console.log(arrayforitrate);
         

         console.log(subname);
         if (subname != "Spouse") { continue; }
         console.log("comin");
         console.log(SOAPDatanode);
         
         member_id=await soapcall.spousesoapUI(arrayforitrate,accHCCID,beneHCCID,zipode,statecode,SSN,sub_id);
      }
    }


      //console.log(SOAPDatanode);
      return{
        SOAPDatanode
      }

   } 
   async function proclaimgetdatafromSoap(claims,fields) 
   {
    var supdata=[];
    var memberandsubdata=[];
    var claimnumber=[];
    //let claim_id;
    //let claim_number
    let arrayforclaimlinenumber=[];
    var SOAPDatanode = [];
    // console.log(claims);
    //console.log(fields.supplierid);
    var supplierid=fields[0].supplierid;
    //console.log(supplierid);
    supdata=await soapcallclaim.getdbvaluesupplier(supplierid);
    supplierdetails=await soapcallclaim.getsupplierdetails(supplierid);
    console.log(supplierdetails);
    //console.log(supdata.arraysupp[0].sublocation);
    for(i=0;i<claims.length;i++)
    {
      // console.log(claims[i].ClaimNumber)
      //console.log(claims[i].Diagnosis);Diagnosis
      // console.log(claims[i].MemberID);
      var memberid=claims[i].MemberID;
      memberandsubdata=await soapcallclaim.getdbvaluesmembsub(memberid);
      //console.log(memberandsubdata);
      for(j=0;j<claims[i].claimDetails.length;j++)
      {
        arrayforclaimlinenumber.push({"Claimlinenumber":claims[i].claimDetails[j].ClaimLineNo,"POS":claims[i].claimDetails[j].POS,"Servicecode":claims[i].claimDetails[j].ServiceCode,"modifier":claims[i].claimDetails[j].Modifier,"UOS":claims[i].claimDetails[j].UOSMOS,"BillAmount":claims[i].claimDetails[j].BillAmount,"PractitionerID":claims[i].claimDetails[j].PractitionerID});
      }
      // console.log(arrayforclaimlinenumber);
      claim_id=await soapcallclaim.proclaimsoapUI(claims[i].MemberID,claims[i].Diagnosis,arrayforclaimlinenumber,fields,supdata,supplierdetails,memberandsubdata);
      arrayforclaimlinenumber=[];
      //console.log("claim_id");
      //console.log(claim_id);
      const claimnum=claim_id.claim_Id;
     // console.log(claimnum);
      claimnumber.push({"Claim_ID":claimnum})
    }
   // var claimnumver=await soapcallclaim.takeclaimid();
    //console.log("claimnumber from UI" + claimnumver);
    return claimnumber;
   }


   async function insclaimgetdatafromSoap(claims,fields) 
   {
    var supdata=[];
    var memberandsubdata=[];
    var claimnumber=[];
    //let claim_id;
    //let claim_number
    let arrayforclaimlinenumber=[];
    var SOAPDatanode = [];
    console.log(claims);
    //console.log(fields.supplierid);
    var supplierid=fields[0].supplierid;
    //console.log(supplierid);
    supdata=await soapcallclaim.getdbvaluesupplier(supplierid);
    supplierdetails=await soapcallclaim.getsupplierdetails(supplierid);
    console.log(supplierdetails);
    //console.log(supdata);
    //console.log(supdata.arraysupp[0].sublocation);
    for(i=0;i<claims.length;i++)
    {
      // console.log(claims[i].ClaimNumber)
      //console.log(claims[i].Diagnosis);Diagnosis
      console.log(claims[i].MemberID);
      var memberid=claims[i].MemberID;
      //var admitdiag=claims[i].AdmitDiagnosis;
      memberandsubdata=await soapcallclaim.getdbvaluesmembsub(memberid);
      //console.log(memberandsubdata);
      for(j=0;j<claims[i].claimDetails.length;j++)
      {
        console.log(claims[i].claimDetails[j]);
        arrayforclaimlinenumber.push({"Claimlinenumber":claims[i].claimDetails[j].ClaimLineNo,"RevenueCode":claims[i].claimDetails[j].RevenueCode,"Servicecode":claims[i].claimDetails[j].ServiceCode,"modifier":claims[i].claimDetails[j].Modifier,"UOS":claims[i].claimDetails[j].UOSMOS,"BillAmount":claims[i].claimDetails[j].BillAmount,"PractitionerID":claims[i].claimDetails[j].PractitionerID});
      }
      // console.log(arrayforclaimlinenumber);
      claim_id=await soapcallclaim.insclaimsoapUI(claims[i].MemberID,claims[i].AdmitDiagnosis,claims[i].PrincipleDiagnosis,claims[i].TypeofBill,arrayforclaimlinenumber,fields,supdata,supplierdetails,memberandsubdata);
      const claimnum=claim_id.claim_Id;
     console.log(claimnum);
      claimnumber.push({"Claim_ID":claimnum})
    }
   return claimnumber;
   }


module.exports = {
  getAccountNames, getBenefitplans,getdatafromSoap,proclaimgetdatafromSoap,insclaimgetdatafromSoap, getServiceCategory,getServicecodedetails
}